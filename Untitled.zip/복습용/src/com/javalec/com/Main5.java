package com.javalec.com;

public class Main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.out.println("1일차");
        //num = 변수의이름 넣어줄수 있음(변수 = 계속 변하는 값)
        //int 정수(ex 1.2.3.4
        //char 문자(ex컴퓨터, 한국, 미래, 사람 등)  
        //double 실수(소수점이하의 값을말함) (ex 1.2131231 , 20,2441,  3,43242
        //string 문자열 (컴퓨터를 쓴다, 코딩을 한다, 등)
        //협업툴
        //1.google docs 
        //2.slack 
        //3.figma
        //4.Notion
        //5.miro
        //6.Github
        //협업툴은 알아서 준비 
       int num1=20, num2=30, num3=40; 
        
        System.out.println("덧셈:" + num1 + "+" +  num2 + "="  + (num1+num2) );
       System.out.println("뺼셈" + num1 + "-" + num2 + "=" + (num1-num2)  );
       System.out.println("나눗셈"+ num1 + "/" + num2 + "=" + (num1/num2) );
       System.out.println( );

   
	}

}
