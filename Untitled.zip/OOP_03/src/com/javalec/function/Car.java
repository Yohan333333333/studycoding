package com.javalec.function;

public class Car {

	//Field 
	public String company = "현대자동차";
	public String model = "그랜";
	public String color = "검정";
	public int maxspeed = 350;
	public int speed;
	
	//Constructor
	public  Car() {
		
	}
	
	
}
