package com.javalec.base;

public class basic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
