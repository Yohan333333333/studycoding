package com.javalec.base;

public class Hello {

	public static void main(String[] args) {
		// 화면에 Hello world 출력하기
        System.out.println("Hello world!");
//	    화면에 안녕하세요 라고 출력
        
        System.out.println("안녕하세요!");
        System.out.println("안녕하세요!");
        }
 public static void main2(String[] args) {
	System.out.println();
}
//   화면에 출력  
   
}
