package com.java.fuction;

public class Evenodd {

	//Property
	
	//COn
	
	
	
	
}
