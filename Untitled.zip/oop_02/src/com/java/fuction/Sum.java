package com.java.fuction;

public class Sum {

	//선언property
	
	//Con
	 public Sum() {
		 
	 }
	//Method
	 int sum= 0;
     for(int i=num1; i <= num2; i++) {
    	 sum=i;
     }
	
}
