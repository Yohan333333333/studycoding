package com.javalec.base;

public class ssssss {

	public static void main(String[] args) {
		// Date Types
		
		// 문자형
	    char char1 = 'C';
	    char char2 ='가';
		
       // 정수형
	   int intNum1 =10;
	   int intNum2 =20;
	   
	   //실수형 
	  double doublenum1 = 10.0;
	  double doublenum2 = 20.0;
	  
	  //문자열 형
	  String str1 = "apple";
	  String str2 = "대한민국";
	  
	  //부울형
	  boolean boo11 = true;
	  boolean boo12 = false;

	  
			  
			  
	 
	}

}
