package com.javalec.base;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// 
		Scanner scanner = new Scanner(System.in);
		int score = 0;
	    String grades = "";
	   
		System.out.println("점수를 입력하세요.");
        
		score = scanner.nextInt();
		
		if() {
			
		}
	}

}
