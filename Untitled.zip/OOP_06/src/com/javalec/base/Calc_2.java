package com.javalec.base;

public class Calc_2 {

	int num1;
	int num2;
	
	public Calc_2() {
		
		
		
	}
	
	
}
