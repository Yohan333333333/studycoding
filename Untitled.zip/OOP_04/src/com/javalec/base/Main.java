package com.javalec.base;

import com.javalec.function.Korean;

public class Main {

	public static void main(String[] args) {
		
		Korean kor = new Korean("홍길동", "010-11111-2222");
//      Korean kor = new Korean();
    	 
    	  
//      kor.name ="홍길동";
//      kor.phone = "010-1111-2222";
//      
//      System.out.println("Nation:" +Kor.nation);
//      System.out.println("name:" + Kor. name);
//      System.out.println("Phone" + Kor. phone);
	
//	kor.printName("홍길동", "010-1111-2222");
	
	
	}

}
