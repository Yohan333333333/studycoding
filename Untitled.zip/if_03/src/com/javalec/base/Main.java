package com.javalec.base;

public class IF_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int i =10;
        int j =20;
        
        if (i > j) {
        	System.out.println("i는 j보다 " + (i-j) + "만큼 큽니다.");
        }else if(i < j){
         System.out.println(" j는i 보다" + (j-i) + "만큼 큽니다.");	
        }else {
        	System.out.println("i와j 는 동일 합니다.");
        }
	}
	
          //Main

}//IF_03 

