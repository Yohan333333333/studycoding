package com.javalec.base;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int num1=1;
	       int num2=10;
	       String result = "";
	       int sum= 0;
	       
	       Evenodd_2 even0dd = new Evenodd_2();
	       
	        
	}

}
