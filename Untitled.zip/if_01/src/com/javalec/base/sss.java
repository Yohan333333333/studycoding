package com.javalec.base;

public class sss {

	public static void main(String[] args) {
		// 조건문
		int i = 10;
		int j = 20;
		int k = 10;
		
		if(i > j)  {
			
			System.out.println(" i가  j 보다 큽니다.");
			
		}
		if (i < j) {
			
			System.out.println(" i 가 j 보다 작습니다.");
	}
    
		if(i == j) { 
			System.out.println("i 와 j는 동일합니다");
		}
		
		
		System.out.println(">>> end <<<");

}
	  
	{  System.out.println("첫번째 숫자를 입력하세요:");
	
	
	
	
	}
	}
	
	
	
	
