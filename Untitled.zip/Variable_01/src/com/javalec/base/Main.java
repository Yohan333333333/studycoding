package com.javalec.base;

public class Main {

	public static void main(String[] args) {
		// 덧셈
	    System.out.println(2 + 3);
		// 뺼셈
	    System.out.println(2 - 3);
		// 곱셈
	    System.out.println(2 * 3);
		// 나눗셈
	    System.out.println(2.0 / 3);
       
	    // ㅡㅡㅡㅡ 변수 ㅡㅡㅡㅡㅡ
	    // num1이라는 변수에 date 10을 할당한다.
	   
	    int num1 = 10; 
	    int num2 = 20;
	    int addition = num1 + num2;
	    double division = (double)num1 / num2;
	    char character1 = 'a';
	   
	    String str1 ="apple";
	    String str2 = "banana";
	   
	   System.out.println(num1);
	   System.out.println(num2);
	   
	    
	    System.out.println(num1 + "+" + num2 + "=" + addition);
	    System.out.println(num1 + "/" + num2 + "=" + division);

	 
	    System.out.println("apple");
	    
	}

}
