package com.javalec.base;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.out.println("Good morning");
        System.out.println("Good Afternoon");
        System.out.println("Good Evening");
        System.out.println("");

        
        System.out.println("반갑습니다");
        System.out.println("<<<<<<>>>>>>");
       
	}

}
